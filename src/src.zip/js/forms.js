new WOW().init();
        $(document).ready(function() {
            $('#brif-form').validate({
                rules: {
                    username: {
                        required: true,
                        minlength: 2,
                        maxlength: 15
                    },
                    email: {
                        required: true,
                        email: true
                    },
                    phone: {
                        required: true
                    }
                },
                messages: {
                    username: "Укажите Ваше имя",
                    email: "Укажите Ваш e-mail",
                    phone: "Укажите Ваш телефон"
                }
            });

            $('#modal-form').validate({
                rules: {
                    username: {
                        required: true,
                        minlength: 2,
                        maxlength: 15
                    },
                    phone: {
                        required: true
                    }
                },
                messages: {
                    username: "Укажите Ваше имя",
                    phone: "Укажите Ваш телефон"
                }
            });

            $('#call-form').validate({
                rules: {
                    username: {
                        required: true,
                        minlength: 2,
                        maxlength: 15
                    },
                    phone: {
                        required: true
                    }
                },
                messages: {
                    username: "Укажите Ваше имя",
                    phone: "Укажите Ваш телефон"
                }
            });

            $('#offer-form').validate({
                errorClass: "invalid",
                errorElement: "div",
                rules: {
                  username: {
                    required: true,
                    minlength: 2,
                    maxlength: 15
                  },
                  phone: "required"
                },
                messages: {
                  username: {
                    required: "Введите имя",
                    minlength: jQuery.validator.format("Требуется не менее {0} символов")
                  },
                  phone: "Заполните поле"
                },
                submitHandler: function (form) {
                  $.ajax({
                        url: 'mail.php',
                        type: 'POST',
                        data: $(form).serialize(),
                        success: function (data) {
                            modal.addClass('modal-offer_active');
                            $('.modal-block').show();
                            $('.modal-block__text').text('Спасибо за заявку, ' + data + ', скоро мы вам перезвоним.');
                            $('input').each(function () {
                              $('input').val('');
                            });
                        }
                  });
                }
              });

            $('.phone').mask('+7 (999) 999-99-99');
            $('.slider').slick({
                slidesToShow: 3,
                slidesToScroll: 1,
                prevArrow: $('.arrows__left'),
                nextArrow: $('.arrows__right'),
                responsive: [
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 1
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1
                        }
                    },   
                ]
            }); 
        });