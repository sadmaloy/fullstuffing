<?php
$data = $_POST;
echo $data['username'];
